from django.apps import AppConfig


class RequestappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "fixful.requestapp"
